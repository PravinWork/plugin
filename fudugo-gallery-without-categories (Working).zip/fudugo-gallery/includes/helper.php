<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );
/**
*  Gallery Helper class.
*/
class GalleryHelper {
	
	/*public $content_table;
	public $category_table;*/
	

	public function __construct() {
		//$content_table  = 'fudugo_gallery_content';
		//$category_table = 'fudugo_gallery_category';
		//echo "constructor loaded.";
		global $table_prefix;
		$GLOBALS[ 'content_table' ] = $table_prefix."fudugo_gallery_content";
		$GLOBALS['category_table'] = $table_prefix."fudugo_gallery_category";
	}

	public function deleteGalleryItem($id) {
		global $table_prefix,$wpdb;
		if(empty($id) || $id==""){
			//echo "Empty id : ".$id;
			return false;
		}

		if ($wpdb->delete($GLOBALS['content_table'], array( 'ID' => $id ) )) {
			return true;
		}else{return false;}
	}

	public function deleteCategory($id) {
		$query = "SELECT * from ".$this->$content_table." where catid='".$id."'";
		$wpdb->get_results($query);
		if($wpdb->num_rows>0){
			return -1;//it indicates data already present for this category
		}else{
			$query = "delete from ".$this->$catgory_table." where id='".$id."'";
			if ($wpdb->get_results($query)) {
				return 1; // successfull operation
			}else{return 0;/* unsuccess or error occured. */}
		}
	}

	public function addNewCategory($data){
		$query = "SELECT title,slug from ".$this->$category_table ." where title like '".$data['title']."' or slug like '".$data['slug']."'";
		$result = $wpdb->get_results($query);
		$stat = 0;
		if($result[0]->status==0){$stat = 1;}
		if($wpdb->update($this->$content_table,array("status"=>$stat),array('id' => $id))){
			return true;
		}else{
			return false;
		}
	}

	function editCategory(){

	}

	public function gallery_item_toggle_status($id) {
		//define( 'WP_DEBUG', true );
		global $table_prefix,$wpdb;
		$content_table = $table_prefix."fudugo_gallery_content";
		
		$query = "SELECT status from ".$content_table ." where id='".$id."'";
		
		$result = $wpdb->get_results($query);

		$stat = 0;
		if($result[0]->status==0){$stat = 1;}
		if($wpdb->update($content_table,array("status"=>$stat),array('id' => $id))){
			if ($stat==1) {
				echo "Active";
			}else{echo "Deactive";}
			return true;
		}else{
			return false;
		}
	}
}