<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );

//echo FUDUGO_PLUGIN_DIR;
 function installDatabaseTables() {

	//fudugo gallery tables
	global $table_prefix,$wpdb;

	$content_table = $table_prefix.'fudugo_gallery_content';
	$category_table = $table_prefix.'fudugo_gallery_categories';
	
	$query = "CREATE TABLE IF NOT EXISTS `$content_table`(
			  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
			  `title` varchar(500) DEFAULT NULL,
			  `media_src` varchar(2000) DEFAULT NULL,
			  `media_type` varchar(100) NOT NULL,
			  `description` varchar(500) DEFAULT NULL,
			  `contact_link` varchar(500) DEFAULT NULL,
			  `sponsored_logo` varchar(500) DEFAULT NULL,
			  `catid` int(11) NOT NULL,
			  `status` int(11) NOT NULL,
			  `modified_date` timestamp NULL DEFAULT NULL,
			  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  				)";

	$wpdb->query($query);

	$query = "CREATE TABLE IF NOT EXISTS `$category_table`(
			  `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
			  `title` varchar(200) NOT NULL,
			  `slug` varchar(200) NOT NULL,
			  `status` tinyint(4) NOT NULL,
			  `modified_date` timestamp NULL DEFAULT NULL,
			  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
  				)";
  	$wpdb->query($query);
}

//for Uninstallation of the plugin over riding from installation LifeCycle .
 function unInstallDatabaseTables() {
	//dropping tables
	global $table_prefix,$wpdb;
	$content_table = $table_prefix.'fudugo_gallery_content';
	$category_table = $table_prefix.'fudugo_gallery_categories';

	$query = "DROP TABLE IF EXISTS `$content_table`";
	$wpdb->query($query);
	$query = "DROP TABLE IF EXISTS `$category_table`";
  	$wpdb->query($query);
}
