<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );
//initialization
require_once(FUDUGO_PLUGIN_DIR."includes/helper.php");

//Ajax Actions
if ( is_admin() ) { //action added for admin user only.

//For Admin Panel
add_action('admin_menu', 'fudugo_gallery_plugin_menu');

function fudugo_gallery_plugin_menu() {
	add_menu_page('Fudugo Gallery Settings', 'Fudogo Gallery', 'administrator', 'fudugo-gallery', 'fudugo_gallery_admin_page', 'dashicons-format-gallery');
	add_submenu_page( 'fudugo-gallery', 'Add new Gallery Item', 'Add New Item', 'administrator', 'fudugo-gallery-addnew.php', 'fudugo_gallery_addnew_item' ); 
	add_submenu_page( 'fudugo-form-submit', 'Add new Gallery Item', 'Add New Gallery Item', 'administrator', 'fudugo-form-submit', 'fudugo_form_submit_page' );
}
function fudugo_gallery_admin_page() { 
	//require_once(FUDUGO_PLUGIN_DIR.'admin/dashboard-1.php');
	require_once(FUDUGO_PLUGIN_DIR.'admin/newdashboard.php');
}

//adding action to form submit
add_action('manage_options','fudugo_form_submit_page');

function fudugo_form_submit_page() {
	require_once(FUDUGO_PLUGIN_DIR.'admin/submit-form.php');
}

//adding styles to admin area
add_action('admin_head', 'add_admin_styles');

function add_admin_styles() {
  echo '<link rel="stylesheet" href="'.FUDUGO_PLUGIN_URL.'css/fudugo_admin_styles.css">';
  echo '<script src="'.FUDUGO_PLUGIN_URL.'js/jquery-3.2.1.min.js"></script>';
  //echo '<script src="'.FUDUGO_PLUGIN_URL.'js/myscript.js"></script>';
}

add_action( 'admin_footer', 'media_selector_print_scripts' );
function fudugo_gallery_addnew_item()
{
	wp_enqueue_media();
	//require_once FUDUGO_PLUGIN_DIR.'admin/addnew.php'; 
	require_once FUDUGO_PLUGIN_DIR.'admin/addnew-1.php'; 
}
 
 //Ajax Actions
add_action('wp_ajax_my_gallery_status','gallery_item_status');
add_action("wp_ajax_nopriv_my_gallery_status", "my_must_login");

function gallery_item_status() {
	$id = $_POST['id'];
	//echo $id;
	$gallery_helper = new GalleryHelper();
	if($gallery_helper->gallery_item_toggle_status($id)){
		//echo "Status Changed.";
	}else{
		echo "Error Ocurred.";
	}
}

add_action('wp_ajax_my_gallery_delete','gallery_item_delete');
add_action("wp_ajax_nopriv_my_gallery_delete", "my_must_login");

function gallery_item_delete() {
	$id = $_POST['id'];
	//echo $id;
	$gallery_helper = new GalleryHelper();
	if($gallery_helper::deleteGalleryItem($id)){
		echo "Success";
	}else{
		echo "Error Ocurred.";
	}
}

// Ajax action to refresh the user image
add_action( 'wp_ajax_myprefix_get_image', 'myprefix_get_image'   );
function myprefix_get_image() {
    if(isset($_GET['id']) ){
        $image = wp_get_attachment_image( filter_input( INPUT_GET, 'id', FILTER_VALIDATE_INT ), 'medium', false, array( 'id' => 'myprefix-preview-image' ) );
        $data = array(
            'image'    => $image,
        );
        wp_send_json_success( $data );
    } else {
        wp_send_json_error();
    }
}

function media_selector_print_scripts() {

	$my_saved_attachment_post_id = get_option( 'media_selector_attachment_id', 0 );

	?><script type='text/javascript'>
		//Pravin
		<?php include FUDUGO_PLUGIN_DIR.'js/admin-inc.js'; ?>
	</script><?php
}

function my_must_login() {
   echo "You must log in to vote";
   die();
}
}