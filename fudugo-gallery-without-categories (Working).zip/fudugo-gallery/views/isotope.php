<?php
defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );
//getting database connection
global $table_prefix,$wpdb;

$db_content = $table_prefix."fudugo_gallery_content";
$db_categories = $table_prefix."fudugo_gallery_categories";
//loading gallery Items 
$query = "SELECT a.*,b.slug FROM $db_content a inner join $db_categories b on a.catid = b.id where b.status>0 and a.status>0 limit 9";

$gallery_items = $wpdb->get_results($query);

//loading gallery categories
$query = "SELECT * from $db_categories where status>0";
$categories = $wpdb->get_results($query); 

?>
<div class="fudugo-button-group" id="fudugo-grid-filters">
	 <button class="button active" data-filter="*">All</button>
	<?php
		foreach($categories as $cat){
			$cat = (array)$cat;
			echo '<button data-filter=".'.$cat['slug'].'">'.$cat['title'].'</button>';
		}
	?>
</div>
<div class="fudugo-grid">
<?php
	foreach ($gallery_items as $value) {  
		$value = (array)$value;
		?>
		<div class="col-md-4 col-sm-12 fudugo-gallary-box <?=$value['slug']?>" data-category="<?=$value['slug']?>"> 
			<?php if('iframe'==$value['media_type']){
				echo html_entity_decode(stripslashes($value['media_src'])); 
			}elseif('image'==$value['media_type']){
				echo '<img src="'.$value['media_src'].'" alt="'.$value['title'].'">';
			}
			?>
			<div class="vid-title"><?=$value['title'];?></div>
			<p><?=$value['description']?></p>
			<div class="fudugo-gallary-box-footer">
			<?php
			if(!is_null($value['contact_link']) && $value['contact_link'] !=""){
				echo '<span class="fudugo-btn-span"><button class="btnContact" onclick="window.location=\''.$value['contact_link'].'\'">Contact</button></span>';
			}
			if(!is_null($value['sponsored_logo'])){
				echo '<span class="pull-right"><img src="img/company-logo1.png" alt="company logo"></span> ';
			}
				?>
			</div>
		</div>	
<?php	}
?>
</div><!-- fudugo-grid -->