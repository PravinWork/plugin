/*
Fudugo Isotope Js : fudugo_isotope.js
*/
// init Isotope
var $grid = $('.fudugo-grid').isotope({
  itemSelector: '.fudugo-gallary-box',
  layoutMode: 'fitRows'
});

// filter functions
var filterFns = {
  // show if number is greater than 50
  numberGreaterThan50: function() {
    var number = $(this).find('.number').text();
    return parseInt( number, 10 ) > 50;
  },
  // show if name ends with -ium
  ium: function() {
    var name = $(this).find('.name').text();
    return name.match( /ium$/ );
  }
};

// bind filter button click
$('#fudugo-grid-filters').on( 'click', 'button', function() {
  var filterValue = $( this ).attr('data-filter');
  $('#fudugo-grid-filters button').removeClass("active");
  $(this).addClass('active');
  // use filterFn if matches value
  filterValue = filterFns[ filterValue ] || filterValue;
  $grid.isotope({ filter: filterValue });
});