<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' ); 
global $wpdb;
$query = "SELECT a.*,b.title as category from fudugo_gallery_content a inner join fudugo_gallery_categories b on a.catid=b.id";
$result = $wpdb->get_results($query);
?>
<div class="container">
<a href="http://www.fudugo.com/" target="_blank">
<img src="http://www.fudugo.com/wp-content/uploads/2017/03/logo-1-1.png" alt="Fudugo Logo" style="max-width:200px;height:auto;">
</a>
<h2><?php _e( 'Fudugo Gallery', 'fudugo-gallery-plugin' ) ?></h2>
<div class="fudugo-gallery" style="padding-right: 15px;">
<a href="admin.php?page=fudugo-gallery-addnew.php">Add new</a>
<form method="post" action="">
<table class="gallery">
	<tr><th>Sr.</th><th>Title</th><th>Media Source</th><th>Media Type</th><th>Category</th><th>Status</th><th>Published</th></tr>
	<?php $i=0;
		foreach ($result as $value) {
			$status = "Deactive";
			echo '<tr>';
			echo '<td>'.++$i.'</td>';
			echo '<td>'.$value->title.'</td>';
			echo '<td>'.$value->media_src.'</td>';
			echo '<td>'.$value->media_type.'</td>';
			echo '<td>'.$value->category.'</td>';
			if(1==$value->status){$status = "Active";}
			echo '<td>'.$status.'</td>';
			$date = date_create($value->created_date);
			echo '<td>'.date_format($date,"D d M Y h:s A").'</td>';
			echo '</tr>';
		}
	?>
</table>
</form> 

<!--<pre>
<?php print_r($result); ?>
</pre>-->
</div>
</div>