<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );
//values initilization
$cmdaction = "insert";
$editid = "";
$edit_img = $edit_iframe = "";

global $table_prefix,$wpdb;
$db_content = $table_prefix."fudugo_gallery_content";
$db_categories = $table_prefix."fudugo_gallery_categories";

$query = "SELECT * from $db_categories";
$result = $wpdb->get_results($query);

if(isset($_GET['editid'])) {
	$query = "SELECT * from $db_content where id ='".$_GET['editid']."'";
	$gallery_item = $wpdb->get_results($query);
	$gallery_item = $gallery_item[0];
	$cmdaction = 'edit';
	$editid = $_GET['editid'];
	if("image" == $gallery_item->media_type){
		$edit_img = $gallery_item->media_src;
	}else{
		$edit_iframe = $gallery_item->media_src;
	}
}
?>
<div class="wrap">
	<h1 class="wp-heading-inline">Add New Gallery Item</h1>

	<hr class="wp-header-end">
	<div id="lost-connection-notice" class="error hidden">
		<p><span class="spinner"></span> <strong>Connection lost.</strong> Saving has been disabled until you’re reconnected.	<span class="hide-if-no-sessionstorage">We’re backing up this post in your browser, just in case.</span>
		</p>
	</div>
	<div id="local-storage-notice" class="hidden notice is-dismissible">
		<p class="local-restore">
			The backup of this post in your browser is different from the version below.		
			<button type="button" class="button restore-backup">Restore the backup</button>
		</p>
		<p class="help">
			This will replace the current editor content with the last backup version. You can use undo and redo in the editor to get the old content back or to return to the restored version.	</p>
			<button type="button" class="notice-dismiss"> <span class="screen-reader-text">Dismiss this notice.</span> </button>
		</div>

		<form name="post" action="<?php echo admin_url('admin.php?page=fudugo-form-submit'); ?>" method="post" id="post">
			<?php wp_nonce_field('fudugo_verify'); ?>
			<input type="hidden" name="cmdaction" value="<?=$cmdaction;?>">
			<input type="hidden" name="editid" value="<?=$editid;?>">
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
					<div id="post-body-content" style="position: relative;">

						<div id="titlediv">
							<div id="titlewrap">
								<input type="text" name="post_title" size="30" value="<?=$gallery_item->title;?>" id="title" spellcheck="true" autocomplete="off" placeholder="Enter title here" >
							</div> 
						</div> <!-- /titlediv -->

						<div id="postdivrich" class="postarea wp-editor-expand">
							<div class="uploader-editor">
								<div class="uploader-editor-content">
									<!-- Addnig Editor Code -->
									<?php wp_nonce_field('fudugo_nonce_action', 'fudugo_nonce_field'); ?>
									<div class="textarea"><textarea id="" name="description" placeholder="Enter description here"><?=$gallery_item->description;?></textarea></div>
									<!-- End Editor Code -->
									<div class='image-preview-wrapper media-upload'>
										<div id="imgdiv" class="col-6">
										<input type="radio" id="image" name="media_type" class="media_type" value="image" <?php if(!empty($edit_img)){echo 'checked';}?>>
										<label for="image">
											<div class='image-preview-wrapper'>
												<img id='image-preview' src='<?=$edit_img;?>' width='250' height='250' style='max-height: 200px; width: 200px;'>
											</div>
											<input id="upload_image_button" type="button" class="button" value="<?php _e( 'Upload image' ); ?>" />
											<input type='hidden' name='image_attachment_url' id='image_attachment_id' value='<?=$edit_img;?> '> 
										</label>
										</div>
										<div class="col-6">
											<input type="radio" id="iframe" class="media_type" name="media_type" value="iframe" <?php if(!empty($edit_iframe)){echo 'checked';}?>><br/>
											<label for="iframe">
											<input type="text" id="youtube-text" name="youtube-text" placeholder="Enter video embed link" value='<?php echo html_entity_decode(stripslashes($edit_iframe));?> '>
											<div id="embed_iframe"><?php echo html_entity_decode(stripslashes($edit_iframe));?></div>
											</label>
										</div>
										
									</div>
									<div class="contact-link">
										<input type="text" name="contact_link" placeholder="Enter contact link here.." value="<?=$gallery_item->contact_link;?>">
									</div>
									

								</div><!-- .uploader-editor-content -->
							</div> <!-- .uploader-editor -->

						</div><!-- #postdivrich -->
					</div><!-- #post-body-content -->
					<!--***********************************************************-->
					<div id="postbox-container-1" class="postbox-container">
						<div id="side-sortables" class="meta-box-sortables ui-sortable">
							<h2 class="hndle ui-sortable-handle"><span>Publish</span></h2>
							<div class="inside">
								<div class="category-select">
									<div id="submitdiv" class="post-box">
										<select name="category">
											<option value="0"> Select Category</option>
									<?php
									foreach ($result as $value) {
									$select ="";
									if($gallery_item->catid == $value->id)
										{$select = "selected";}
									echo '<option value="'.$value->id.'" '.$select.'>'.$value->title.'</option>';
									}
									//$status = $gallery_item->status;
									?>
										</select>
										<div class="status-div">
											<label>Status : </label>
											<input id="stat-1" type="radio" name="status" value="1" checked="true">
											<label for="stat-1">Active</label>
											<input id="stat-2" type="radio" name="status" value="0" <?php if($gallery_item->status == 0){echo 'checked="true"';}?>>
											<label for="stat-2">Deactive</label>
										</div>
										<?php submit_button('Save', 'primary'); ?>
									</div>
									
								</div>
							</div>
						</div>
					</div>
					<!-- ********************************************************* -->
				</div><!-- #post-body -->

			</div> <!-- #poststuff -->
		</form>
		<script type="text/javascript">
			$('#youtube-text').click(function(){
				//$('#media-type').val('iframe');
				$('#iframe').click();
			});
			$('#upload_image_button').click(function(){
				$('#image').click();
			});
			$(document).ready(function(){
			    $("#youtube-text").keyup(function(){ 
			        $("#embed_iframe").html($(this).val());
			    });
			});
		</script>
</div><!--.wrap-->