<?php defined('ABSPATH') or die("Access Denied");

?>
<div class="wrap">
	<h1 class="wp-heading-inline">Add New Gallery Item</h1>

	<hr class="wp-header-end">
	<div id="lost-connection-notice" class="error hidden">
		<p><span class="spinner"></span> <strong>Connection lost.</strong> Saving has been disabled until you’re reconnected.	<span class="hide-if-no-sessionstorage">We’re backing up this post in your browser, just in case.</span>
		</p>
	</div>
	<div id="local-storage-notice" class="hidden notice is-dismissible">
		<p class="local-restore">
			The backup of this post in your browser is different from the version below.		<button type="button" class="button restore-backup">Restore the backup</button>
		</p>
		<p class="help">
			This will replace the current editor content with the last backup version. You can use undo and redo in the editor to get the old content back or to return to the restored version.	</p>
			<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>


			<form name="post" action="<?php echo admin_url('admin.php?page=fudugo-form-submit'); ?>" method="post" id="post">
				<?php wp_nonce_field('fudugo_verify'); ?>

				<div id="poststuff">
					<div id="post-body" class="metabox-holder columns-2">
						<div id="post-body-content" style="position: relative;">

							<div id="titlediv">
								<div id="titlewrap">
									<input type="text" name="post_title" size="30" value="" id="title" spellcheck="true" autocomplete="off" placeholder="Enter title here">
								</div>
								<div class="inside">
									<div id="edit-slug-box" class="hide-if-no-js">
									</div>
								</div>
							</div> <!-- /titlediv -->

							<div id="postdivrich" class="postarea wp-editor-expand">
								<div class="uploader-editor">
									<div class="uploader-editor-content">
									<!-- Addnig Editor Code -->
									 <?php
									 wp_nonce_field('nates_nonce_action', 'nates_nonce_field');

          							$content = get_option('special_content');
          							wp_editor( $content, 'special_content' );

         							 ?>
          							<!-- End Editor Code -->
										<div class='image-preview-wrapper'>

											<div class='image-preview-wrapper'>
											<img id='image-preview' src='' width='250' height='250' style='max-height: 200px; width: 200px;'>
											</div>
											<input id="upload_image_button" type="button" class="button" value="<?php _e( 'Upload image' ); ?>" />
											<input type='hidden' name='image_attachment_url' id='image_attachment_id' value=''>
											<input type="hidden" id="media-type" name="media_type" value="">

											<?php submit_button('Save', 'primary'); ?>
										</div>

									</div><!-- .uploader-editor-content -->
								</div> <!-- .uploader-editor -->

							</div><!-- #postdivrich -->
						</div><!-- #post-body-content -->
					</div><!-- .post-body -->
				</div> <!-- #poststuff -->
			</form>
</div><!--.wrap-->