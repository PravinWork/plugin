<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' ); 
global $table_prefix,$wpdb;
$db_content = $table_prefix."fudugo_gallery_content";
$db_categories = $table_prefix."fudugo_gallery_categories";
$query = "SELECT a.*,b.title as category from $db_content a left join $db_categories b on a.catid=b.id order by created_date desc";
$result = $wpdb->get_results($query);
?> 
<div class="wpwrap">
<h1 class="wp-heading-inline">Gallery <a href="admin.php?page=fudugo-gallery-addnew.php" class="page-title-action">Add New</a></h1>
<hr class="wp-header-end">
<div class="main-gallery-content">
<div id="post-body" class="metabox-holder columns-2">
	<div id="post-body-content">
	<ul class="gallery-table"> 
		<?php 
		if(count($result)<=0){echo "No Gallery Items Found.";}
		foreach ($result as $key => $value) { ?>
		<li class="fudugo-item-<?=$value->id;?>">
			<div class="iframe"><?php if("iframe" == $value->media_type){echo html_entity_decode(stripslashes( $value->media_src));}elseif("image"==$value->media_type){echo '<img src="'.$value->media_src.'" alt="" />';} ?></div>
			<div class="desc"><div class="col-1">
				<div class="row"><label for="title">Title</label><input id="title" type="text" name="title" value="<?= $value->title;?>"></div>
				<div class="row"><label for="description">Description</label><textarea id="description" type="text" name="description"><?= $value->description;?></textarea></div>
				<div class="row"><label for="link">Link</label><input id="link" type="text" name="link" value="<?= $value->contact_link;?>"></div>
				</div>
				<div class="col-2">
					<div class="row"><label>Published:</label><?=date_format(new DateTime($value->created_date),"d M Y H:m A");?></div>
					<div class="row"><label>Modified:</label>
					<?php if($value->modified_date!="" && $value->modified_date!="0000-00-00 00:00:00"){echo date_format(new DateTime($value->modified_date),"d M Y H:m A");}else{echo "-";}?></div>
					<div class="row"><label>Category : <?=$value->category;?></label></div>
					<div class="row"><label style="float: left;margin-right: 5px;">Status : <span id="content-stat-<?=$value->id;?>"><?php if($value->status>0){echo 'Active </span></label> ';echo '<button title="Change Status" id="'.$value->id.'" class="change-status"><span class="dashicons dashicons-visibility"></span></button>';}else{echo 'Deactive </span></label> ';echo '<button title="Change Status" id="'.$value->id.'" class="change-status"><span class="dashicons dashicons-hidden"></span></button>';}?> </div>
					<div class="controls"><button title="Edit" onclick="window.location='admin.php?page=fudugo-gallery-addnew.php&editid=<?= $value->id;?>';"><span class="dashicons dashicons-edit"></span></button>
					<button title="Delete" class="delete-gallery-item" data-id="<?=$value->id;?>"><span class="dashicons dashicons-trash"></span></button></div>
				</div>
			</div> 
			
		</li>
		<?php } ?>
	</ul>
	</div>
</div>
</div>
</div>
<script type="text/javascript">
    jQuery(document).ready(function($) {
	$("button.change-status").click(function(){
		var id = $(this).attr("id");
		var data = {
			'action': 'my_gallery_status',
			'id':id 
			  // We pass php values differently!
		};
		//We can also pass the url value separately from ajaxurl for front end AJAX implementations
		var url = "admin-ajax.php";
		jQuery.post(url, data, function(response) {
			//alert('Message : ' + response);
			if(response=="Active0"){
				$("#content-stat-"+id).html("Active ");
				$('#'+id).html('<span class="dashicons dashicons-visibility"></span>');
			}else{
				$("#content-stat-"+id).html("Deactive ");
				$('#'+id).html('<span class="dashicons dashicons-hidden"></span>');
			}
		});
	});

	$("button.delete-gallery-item").click(function(){
		if(confirm("Are you sure you want to delete?")){
			var id = $(this).attr("data-id");
			var data = {
				'action': 'my_gallery_delete',
				'id':id 
			};
			var url = "admin-ajax.php";
			jQuery.post(url, data, function(response) { 
				if(response == "Success0"){$("li.fudugo-item-"+id).remove();}
				else{alert("Unable to delete id:"+id);}
			});
		}
	});
	
	});//document ready
</script>