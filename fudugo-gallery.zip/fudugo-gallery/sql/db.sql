--table fudugo_gallery_contents

CREATE TABLE `fudugo_gallery_content` 
( `id` INT NOT NULL AUTO_INCREMENT , `title` VARCHAR(500) NULL , 
  `media_src` VARCHAR(2000) NULL , `media_type` VARCHAR(100) NOT NULL , 
  `description` VARCHAR(500) NULL , `contact_link` VARCHAR(500) NULL , 
  `sponsored_logo` VARCHAR(500) NULL , `catid` INT NOT NULL , 
  `modified_date` TIMESTAMP NULL , 
  `created_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
   PRIMARY KEY (`id`)
) ENGINE = InnoDB;