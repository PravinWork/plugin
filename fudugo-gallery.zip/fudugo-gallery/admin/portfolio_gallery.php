<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' ); 
global $table_prefix,$wpdb;
$db_content = $table_prefix."fudugo_gallery_content";
$db_categories = $table_prefix."fudugo_gallery_categories";
$db_portfolio = $table_prefix."fudugo_gallery_portfolio";

function sendBack() {
	echo '<script type="text/javascript">window.location.href="admin.php?page=fudugo-gallery";
		 </script>';
}

if(isset($_GET["portid"])){
	$portid = $_GET["portid"];
	$query = "SELECT title from $db_portfolio where id=$portid";
	$title = $wpdb->get_var($query);
	if (empty($title) || is_null($title)) {
		sendBack();
	}
}else{
	sendBack();
} 

$query = "SELECT a.*,b.title as category from $db_content a left join $db_categories b on a.catid=b.id where portfolio_id = $portid order by created_date desc";
$result = $wpdb->get_results($query);

$query = "SELECT id,title,status from $db_categories";
$categories = $wpdb->get_results($query);
?> 
<div class="wpwrap">
<h1 class="wp-heading-inline"><?=$title;?> - Gallery 
<a href="admin.php?page=fudugo-gallery-addnew.php&portid=<?=$portid;?>" class="page-title-action">Add New</a></h1>
<hr class="wp-header-end">
<div class="main-gallery-content">
<div id="post-body" class="metabox-holder columns-2">
	<div id="post-body-content">
	<ul class="gallery-table"> 
		<?php 
		if(count($result)<=0){echo "No Gallery Items Found.";}
		foreach ($result as $key => $value) { ?>
		<li class="fudugo-item-<?=$value->id;?>">
			<div class="iframe"><?php if("iframe" == $value->media_type){echo html_entity_decode(stripslashes( $value->media_src));}elseif("image"==$value->media_type){echo '<img src="'.$value->media_src.'" alt="" />';} ?></div>
			<div class="desc"><div class="col-1">
				<div class="row"><label for="title">Title</label><input id="title" type="text" name="title" value="<?=$value->title;?>"></div>
				<div class="row"><label for="description">Description</label><textarea id="description" type="text" name="description"><?= $value->description;?></textarea></div>
				<div class="row"><label for="link">Link</label><input id="link" type="text" name="link" value="<?= $value->contact_link;?>"></div>
				</div>
				<div class="col-2">
					<div class="row"><label>Published :</label><?=date_format(new DateTime($value->created_date),"d M Y h:i A");?></div>
					<div class="row"><label>Modified :</label>
					<?php if($value->modified_date!="" && $value->modified_date!="0000-00-00 00:00:00"){echo date_format(new DateTime($value->modified_date),"d M Y h:i A");}else{echo "-";}?></div>
					<div class="row"><label>Category : </label><?php if(!empty($value->category)){echo $value->category;}else{echo "Uncategorized";}?></div>
					<div class="row"><label style="float: left;margin-right: 5px;">Status : <span id="content-stat-<?=$value->id;?>"><?php if($value->status>0){echo 'Active </span></label> ';echo '<button title="Change Status" id="'.$value->id.'" class="change-status"><span class="dashicons dashicons-visibility"></span></button>';}else{echo 'Deactive </span></label> ';echo '<button title="Change Status" id="'.$value->id.'" class="change-status"><span class="dashicons dashicons-hidden"></span></button>';}?> </div>
					<div class="controls"><button title="Edit" onclick="window.location='admin.php?page=fudugo-gallery-addnew.php&editid=<?= $value->id;?>';"><span class="dashicons dashicons-edit"></span></button>
					<button title="Delete" class="delete-gallery-item" data-id="<?=$value->id;?>"><span class="dashicons dashicons-trash"></span></button></div>
				</div>
			</div> 
			
		</li>
		<?php } ?>
	</ul>
	</div>
</div><!--#post body-->
<div class="categories">
	<div>
		<h3>Categories</h3>
		<hr>
		<label id="cat-msgs">&nbsp; </label>
	</div>
	<form id="category-form" method="post" class="categories-form">
	<input type="hidden" name="action" value="add_category">
	<input type="hidden" id="editid" name="editid" value="">
	<input type="hidden" name="" value="">
	<?php wp_nonce_field('fudugo_verify'); ?>
	<div>
		<input type="text" id="inp-title" name="category" placeholder="Enter Category">
	</div>
	<div>
		<input type="radio" id="status-active" name="status" value="1" checked>
		<label for="status-active">Active</label>
		<input type="radio" id="status-deactive" name="status" value="0">
		<label for="status-deactive">Deactive</label>
	</div>
	<div>
		<input type="submit" class="button button-primary" name="save-category" value="Save">
		<input type="button" id="btnClear" class="button button-primary" name="clear" value="Clear">
	</div>
			
	</form>
	<div class="cat-table">
		<table class="gallery widefat">
			<thead><th>Category</th><th>Action</th></thead>
			<tfoot><th>Category</th><th>Action</th></tfoot>
			<tbody>
				<?php
				if (count($categories)<=0) {
					echo '<tr><td colspan=2>No Categires Found.</td></tr>';
				}
		        foreach ($categories as $key => $value) {
		     		echo '<tr id="tr-'.$value->id.'"><td class="title-'.$value->id.'">'.$value->title.'</td><td>';
		     		if($value->status==1){
		     		echo '<button data-id="'.$value->id.'" class="cat-status status-'.$value->id.'" status="1"><span class="dashicons dashicons-visibility"></span></button>';
		     		}else{
		     		echo '<button data-id="'.$value->id.'" class="cat-status status-'.$value->id.'" status="0"><span class="dashicons dashicons-hidden"></span></button>';
		     		}
		     		echo '<button class="edit" data-id="'.$value->id.'"><span class="dashicons dashicons-edit"></span></button>';
		     		echo '<button data-id="'.$value->id.'" class="delete"><span class="dashicons dashicons-trash"></span></button>';
		     		echo '</td></tr>';
		        }
				?>
			</tbody>
		</table>
	</div>
</div>
</div>
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
$("button.change-status").click(function(){
	var id = $(this).attr("id");
	var data = {
		'action': 'my_gallery_status',
		'id':id 
	};
	var url = "admin-ajax.php";
	jQuery.post(url, data, function(response) { 
		if(response=="Active0"){
			$("#content-stat-"+id).html("Active ");
			$('#'+id).html('<span class="dashicons dashicons-visibility"></span>');
		}else{
			$("#content-stat-"+id).html("Deactive ");
			$('#'+id).html('<span class="dashicons dashicons-hidden"></span>');
		}
	});
});

$("button.delete-gallery-item").click(function(){
	if(confirm("Are you sure you want to delete?")){
		var id = $(this).attr("data-id");
		var data = {
			'action': 'my_gallery_delete',
			'id':id 
		};
		var url = "admin-ajax.php";
		jQuery.post(url, data, function(response) { 
			if(response == "Success0"){$("li.fudugo-item-"+id).remove();}
			else{alert("Unable to delete id:"+id);}
		});
	}
});

$("form#category-form").submit(function(event){ 
	event.preventDefault();
	if($("#inp-title").val()==""){$("#inp-title").focus();return;}
	
	var id = $(this).attr("data-id");
	var data = $('form#category-form').serialize();
	var url = "admin-ajax.php";
	jQuery.post(url, data, function(response) {
		if (response.success) {
			$("#cat-msgs").html(response.data);
			if(response.data=="Saved.."){$(".cat-table table").append('<tr id="tr-15"><td>Test</td><td><button data-id="15"><span class="dashicons dashicons-visibility"></span></button><button><span class="dashicons dashicons-edit"></span></button><button data-id="15" class="delete"><span class="dashicons dashicons-trash"></span></button></td></tr>');}
		}else{
			$("#cat-msgs").html(response);
		}
	}); 
});

$("button.delete").click(function(event){   
	if(confirm("Are you sure you want to delete?")){
		var id = $(this).attr("data-id");
		var data = {
			'action': 'my_gallery_category_delete',
			'id':id 
		};
		var url = "admin-ajax.php";
		jQuery.post(url, data, function(response) { 
			if(response.success){$("tr#tr-"+id).remove();}
			else{alert("Unable to delete id:"+id);}
		});
	}
});

$("button.edit").click(function(event){   
	var id = $(this).attr("data-id");
	var status = $("button.status-"+id).attr("status");
	$("#editid").val(id);
	var title = $(".title-"+id).html();
	$("#inp-title").val(title);
	if(status==1){$("#status-active").prop("checked", true);}
	else{$("#status-deactive").prop("checked", true);}
});

$("#btnClear").click(function(){
	$("#editid").val("");
	$("#inp-title").val("");
	$("#status-active").prop("checked", true);
});

$("button.cat-status").click(function(){
	var btn = $(this);
	var id = $(this).attr("data-id");
	var data = {
		'action': 'my_gallery_category_status',
		'id':id 
	};
	var url = "admin-ajax.php";
	jQuery.post(url, data, function(response) { 
		if(response=="Active0"){
			btn.html('<span class="dashicons dashicons-visibility"></span>');
		}else{
			btn.html('<span class="dashicons dashicons-hidden"></span>');
		}
	});
});
});//document ready
</script>