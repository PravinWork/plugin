<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' ); 
require_once(FUDUGO_PLUGIN_DIR."includes/pagination.class.php");
global $table_prefix,$wpdb;
$db_portfolio = $table_prefix."fudugo_gallery_portfolio";
$db_gallery = $table_prefix."fudugo_gallery_content";
//$db_content = $table_prefix."fudugo_gallery_content";
//$db_categories = $table_prefix."fudugo_gallery_categories";
//$query = "SELECT a.*,b.title as category from $db_content a left join $db_categories b on a.catid=b.id";
$query = "SELECT *,(select count(id) from $db_gallery where portfolio_id = a.id) as items from $db_portfolio a";
$result = $wpdb->get_results($query);
$items = $wpdb->num_rows;

if($items > 0) {
    $p = new pagination;
    $p->items($items);
    $p->limit(20); // Limit entries per page
    $p->target("admin.php?page=fudugo-gallery"); 
    $p->currentPage($_GET[$p->paging]); // Gets and validates the current page
    $p->calculate(); // Calculates what to show
    $p->parameterName('paging');
    $p->adjacents(1); //No. of page away from the current page
             
    if(!isset($_GET['paging'])) {
        $p->page = 1;
    } else {
        $p->page = $_GET['paging'];
    }
     
    //Query for limit paging
    $limit = "LIMIT " . ($p->page - 1) * $p->limit  . ", " . $p->limit;
         
} else {
    echo "No Record Found";
}

?>
<div class="container">
<div class="row company-logo">
<a href="http://www.fudugo.com/" target="_blank">
<img src="http://www.fudugo.com/wp-content/uploads/2017/03/logo-1-1.png" alt="Fudugo Logo">
</a>
</div>
<h2><?php _e( 'Gallery Portfolio', 'fudugo-gallery-plugin' ) ?> <a href="admin.php?page=add-new-portfolio" class="page-title-action">Add new</a></h2>

<div class="fudugo-gallery">

<table class="gallery widefat">
<thead>
    <tr>
        <th>Title</th>       
        <th>Description</th>
    	<th>Gallery Items</th>
        <th>Shortcodes</th>
        <th>Status</th>
        <th>Modified</th>
        <th>Published</th>
        <th>Actions</th>
    </tr>
</thead>
<tfoot>
    <tr>
    <th>Title</th>
    <th>Description</th>
    <th>Gallery Items</th>
    <th>Shortcodes</th>
    <th>Status</th>
    <th>Modified</th>
    <th>Published</th>
    <th>Actions</th>
    </tr>
</tfoot>
	<?php $i=0;
		if ($items<=0) {
			echo '<tr><td colspan="5"><strong>No Portfolio found. Create New Portfolio.</strong></td></tr>';
		}
		foreach ($result as $value) {
			$status = "Deactive";
			echo '<tr id="tr-'.$value->id.'">';
			echo '<td><a href="admin.php?page=portfolio-gallery&portid='.$value->id.'">'.$value->title.'</a></td>';
			echo '<td>'.$value->description.'</td>';
			echo '<td>'.$value->items.'</td>';
			echo '<td>'.$value->shortcode.'</td>';
			if(1==$value->status){$status = "Active";}
			echo '<td>'.$status.'</td>';
			if (!is_null($value->modified_date) && !empty($value->modified_date)) {
				$date = date_create($value->modified_date);
				$date = date_format($date,"D d M Y h:i A");
			}else{
				$date = "-";
			}
			echo '<td>'.$date.'</td>';
			$date = date_create($value->created_date);
			echo '<td>'.date_format($date,"D d M Y h:i A").'</td>';

			echo '<td class="controls">';
			echo '<button class="button-primary gallery" onclick="window.location=\'admin.php?page=portfolio-gallery&portid='.$value->id.'\';"><span class="dashicons dashicons-images-alt"></span></button>';
			echo '<button class="button-primary edit" onclick="window.location=\'admin.php?page=add-new-portfolio&editid='.$value->id.'\';"><span class="dashicons dashicons-edit"></span></button>';
			echo '<button class="button-primary delete" data-id="'.$value->id.'"><span class="dashicons dashicons-trash"></span></button>';
			echo '</td>';
			echo '</tr>';
		}
	?>
</table>
<!-- </form>  -->
<script type="text/javascript">
	$("button.delete").click(function(){
		var id=$(this).attr("data-id");
		var url="admin-ajax.php"; 
		$.post(url,{
			"action":"delete_portfolio",
			"id":id
		    },function(response){
		    	if(response=="deleted0"){
		    		$("tr#tr-"+id).remove();
		    	}else{
		    		alert("unable to delete.");
		    	}
			});
	});
</script>
</div>
</div>