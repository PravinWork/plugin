<?php defined('ABSPATH') or die("Access Denied");

global $table_prefix,$wpdb;
$db_portfolio = $table_prefix."fudugo_gallery_portfolio";

$editflag = false;

if (isset($_GET["editid"]) && !empty($_GET["editid"])) {
	$query = "SELECT * from $db_portfolio where id='".$_GET["editid"]."'";
	$portfolio = $wpdb->get_row($query);
	$editflag = true;
}else{
	$get_id = $wpdb->get_row("SHOW TABLE STATUS LIKE '$db_portfolio'"); 
	$last_id = $get_id->Auto_increment;
	$editflag = false;
}
 //print_r($portfolio);
?>
<div class="wrap">
	<h1 class="wp-heading-inline">Add New Portfolio</h1>

	<hr class="wp-header-end">
	<div id="lost-connection-notice" class="error hidden">
		<p><span class="spinner"></span> <strong>Connection lost.</strong> Saving has been disabled until you’re reconnected.	<span class="hide-if-no-sessionstorage">We’re backing up this post in your browser, just in case.</span>
		</p>
	</div>
	<div id="local-storage-notice" class="hidden notice is-dismissible">
		<p class="local-restore">
			The backup of this post in your browser is different from the version below.		<button type="button" class="button restore-backup">Restore the backup</button>
		</p>
		<p class="help">
			This will replace the current editor content with the last backup version. You can use undo and redo in the editor to get the old content back or to return to the restored version.	</p>
			<button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>

			<form name="post" action="<?php echo admin_url('admin.php?action=insert_portfolio'); ?>" method="post" id="post">
				<?php wp_nonce_field('fudugo_verify'); ?>
				<input type="hidden" name="shortcode" value="<?php if(!$editflag){echo '[FUDUGO_GALLERY id='.$last_id.']';}else{echo $portfolio->shortcode;}?> ">
				<?php if($editflag){echo '<input type="hidden" name="editid" value="'.$portfolio->id.'">';} ?>
				<div id="poststuff">
					<div id="post-body" class="metabox-holder columns-2">
						<div id="post-body-content" style="position: relative;">

							<div id="titlediv">
								<div id="titlewrap">
									<input type="text" name="post_title" size="30" value="<?=$portfolio->title?>" id="title" spellcheck="true" autocomplete="off" placeholder="Enter title here">
								</div>
								
							</div> <!-- /titlediv -->

							<div id="postdivrich" class="postarea wp-editor-expand">
								<div class="uploader-editor">
									<div class="uploader-editor-content">
									<!-- Addnig Editor Code -->
							<?php wp_nonce_field('fudugo_nonce_action', 'fudugo_nonce_field'); ?>
         							 <div class="textarea"><textarea id="desc" name="description" placeholder="Enter description here"><?=$portfolio->description?></textarea></div>
          							<!-- End Editor Code -->
          							<div class="row shortcode"><input type="text" id="shortcode" name="shortcode" placeholder="Shortcode" value="<?php if(!$editflag){echo '[FUDUGO_GALLERY id='.$last_id.']';}else{echo $portfolio->shortcode;}?> " disabled></div>
          							<div class="row">
          							<input type="radio" name="status" id="status-active" value='1' checked>
          							<label for="status-active">Active</label>
          							<input type="radio" name="status" id="status-deactive" value="0" <?php if ($portfolio->status==0) {echo "checked"; }?>>
          							<label for="status-deactive">Deactive</label>
          							</div>
											<?php submit_button('Save', 'primary'); ?>
									</div>

									</div><!-- .uploader-editor-content -->
								</div> <!-- .uploader-editor -->

							</div><!-- #postdivrich -->
						</div><!-- #post-body-content -->
					</div><!-- .post-body -->
				</div> <!-- #poststuff -->
			</form>
</div><!--.wrap-->