<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );

if(isset($_POST['cmdaction']) && !empty($_POST) && !empty($_POST['_wpnonce']) &&  check_admin_referer('fudugo_nonce_action', 'fudugo_nonce_field')){
	global $table_prefix,$wpdb;
		
	$table = $table_prefix."fudugo_gallery_content"; 

	$data = array('title'=> '','description'=>'','media_type'=>'','media_src'=>'',
				  'contact_link'=>'','catid'=>'','status'=>''
				 );
	if(isset($_POST['post_title']) && !empty($_POST['post_title'])){
		$data['title'] = $_POST['post_title'];
	}
	if(isset($_POST['description']) && !empty($_POST['description'])){
		$data['description'] = $_POST['description'];
	}
	if(isset($_POST['media_type']) && !empty($_POST['media_type'])){
		$data['media_type'] = $_POST['media_type'];
	}
	if('image'== $_POST['media_type']){
		if(isset($_POST['image_attachment_url']) && !empty($_POST['image_attachment_url'])){
			$data['media_src'] = $_POST['image_attachment_url'];
		}
	}elseif('iframe'==$_POST['media_type']){
		if(isset($_POST['youtube-text']) && !empty($_POST['youtube-text'])){
			$data['media_src'] = html_entity_decode($_POST['youtube-text']);
		}
	}
	
	if(isset($_POST['contact_link']) && !empty($_POST['contact_link'])){
		$data['contact_link'] = $_POST['contact_link'];
	}
	if(isset($_POST['category']) && !empty($_POST['category'])){
		$data['catid'] = $_POST['category'];
	}

	if(isset($_POST['portid']) && !empty($_POST['portid'])){
		$data['portfolio_id'] = $_POST['portid'];
	}

	$data['status'] = $_POST['status']; 
    if ("insert"==$_POST['cmdaction']) {
    	
		if($wpdb->insert($table , $data)){
			echo "<h1>Added Succesfully.</h1>";
		?>
		<script type="text/javascript">
			window.location.href="admin.php?page=portfolio-gallery&portid=<?=$_POST['portid'];?>";
		</script>
	<?php
		}else{
			echo "<h1>Error Occured.</h1><div><a href=\"admin.php?page=portfolio-gallery&portid=".$_POST['portid']."\">Back</a></div>";
		}
	}elseif ("edit"==$_POST['cmdaction']) {
		# update query
		$data['modified_date'] = current_time("Y-m-d H:i:s");//date_format(new DateTime(),"Y-m-d H:i:s");
		if($wpdb->update($table,$data,array('id' => $_POST['editid']))){
			echo "<h1>Updated Succesfully.</h1>";
		?>
		<script type="text/javascript">
			window.location.href="admin.php?page=portfolio-gallery";
		</script>
	<?php
		}else{
			echo "<h1>Error Occured.</h1><div><a href=\"admin.php?page=portfolio-gallery&portid=".$_POST['portid']."\">Back</a></div>";
		}
	}

} else{
?>
	<div>
		<a href="admin.php?page=fudugo-gallery">Back</a>
		<script type="text/javascript">
			window.location.href="admin.php?page=fudugo-gallery&portid=".$_POST['portid']."";
		</script>
	</div>
<?php }

