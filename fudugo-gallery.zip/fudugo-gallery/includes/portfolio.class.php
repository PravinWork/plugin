<?php 
/**
* Portfolio Helper class
*/
class PortfolioHelper {
	
	function __construct() {
		global $table_prefix;
		$GLOBALS['portfolio_table'] = $table_prefix."fudugo_gallery_portfolio";
		$GLOBALS['portfolio_options'] = $table_prefix."fudugo_gallery_portfolio_options";
	}

	function insert($data) { 
		global $wpdb;
		$array = array("title"=>"","description"=>"","shortcode"=>"");
		if (count($data)<=0) { //('fudugo_nonce_action', 'fudugo_nonce_field')
			return false;
		}
		$array["title"] = $data["post_title"];
		$array["description"] = $data["description"];
		$array["shortcode"] = $data["shortcode"];
		$array["status"] = $data["status"];

		if($wpdb->insert($GLOBALS['portfolio_table'] , $array)) {
			return true;
		}else{
			return false;
		}
	}

	function delete($id){
		//code $wpdb->delete();
		global $wpdb;
		if(!empty($id)){
			if($wpdb->delete($GLOBALS['portfolio_table'],array("id"=>$id))){
				return true;
			}
		}
		return false;
	}

	function update($data){
		//code $wpdb->update()
		global $wpdb;
		$array = array("title"=>"","description"=>"","status"=>"0");

		$array["title"] = $data["post_title"];
		$array["description"] = $data["description"];
		$array["status"] = $data["status"];
		$array["modified_date"] = current_time("Y-m-d H:i:s");//date_format(new DateTime(),"Y-m-d H:m:s");

		if($wpdb->update($GLOBALS['portfolio_table'], $array, array("id"=>$data["editid"]))) {
			return true;
		}else{
			return false;
		}
	}

	function setOptions($data){
		//code $wpdb->update() or $wpdb->insert()
	}
}