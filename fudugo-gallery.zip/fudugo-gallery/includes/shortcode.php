<?php
defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );

function fudugo_shortcodes_init()
{
    function fudugo_shortcode($atts = [], $content = null)
    {
    	wp_enqueue_style('fudugo-css'); 
    	wp_enqueue_script('fudugo-jquery-min');
    	wp_enqueue_script('fudugo-script-min');
    	wp_enqueue_script('fudugo-script');
    	require FUDUGO_PLUGIN_DIR.'views/isotope.php';
    }
    add_shortcode('FUDUGO_GALLERY', 'fudugo_shortcode');
}
add_action('init', 'fudugo_shortcodes_init');
