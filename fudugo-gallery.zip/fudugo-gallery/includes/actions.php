<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );
//initialization
require_once(FUDUGO_PLUGIN_DIR."includes/helper.php");
require_once(FUDUGO_PLUGIN_DIR."includes/portfolio.class.php");

//Ajax Actions
if ( is_admin() ) { //action added for admin user only.

//For Admin Panel
add_action('admin_menu', 'fudugo_gallery_plugin_menu');

function fudugo_gallery_plugin_menu() {
	add_menu_page('Fudugo Gallery Settings', 'Fudogo Portfolio', 'administrator', 'fudugo-gallery', 'fudugo_portfolio_gallery', 'dashicons-format-gallery');
	add_submenu_page( 'fudugo-gallery', 'Gallery Settings Page', 'Portfolio Settings', 'administrator', 'portfolio-gallery-settings', 'fudugo_gallery_settings' );
	add_submenu_page( 'fudugo_gallery_admin_page', 'Gallery Page', 'Portfolio Gallery', 'administrator', 'portfolio-gallery', 'fudugo_gallery_admin_page' );
	add_submenu_page( 'fudugo-gallery-add', 'Add new Gallery Item', 'Add New Item', 'administrator', 'fudugo-gallery-addnew.php', 'fudugo_gallery_addnew_item' ); 
	add_submenu_page( 'fudugo-form-submit', 'Add new Gallery Item', 'Add New Gallery Item', 'administrator', 'fudugo-form-submit', 'gallery_add_new_form_submit_page' );
	add_submenu_page( 'fudugo_portfolio_gallery', 'Add new Portfolio', 'Add New Portfolio', 'administrator', 'add-new-portfolio', 'add_new_porfolio' );
}
function fudugo_gallery_admin_page() {   
	require_once(FUDUGO_PLUGIN_DIR.'admin/portfolio_gallery.php'); 
}

function fudugo_gallery_settings() {
	echo "<h2>Settings Page</h2>";
}

function fudugo_portfolio_gallery(){
	require_once(FUDUGO_PLUGIN_DIR.'admin/dashboard.php');
}
 
 //page to submit add new gallery item page
function gallery_add_new_form_submit_page() {
	require_once(FUDUGO_PLUGIN_DIR.'admin/submit-form.php');
}

function add_new_porfolio() {
	require_once(FUDUGO_PLUGIN_DIR."admin/addnewportfolio.php");
}

//adding styles to admin area
add_action('admin_head', 'add_admin_styles');

function add_admin_styles() {
  echo '<link rel="stylesheet" href="'.FUDUGO_PLUGIN_URL.'css/fudugo_admin_styles.css">';
  echo '<script src="'.FUDUGO_PLUGIN_URL.'js/jquery-3.2.1.min.js"></script>';
  //echo '<script src="'.FUDUGO_PLUGIN_URL.'js/myscript.js"></script>';
}

add_action( 'admin_footer', 'media_selector_print_scripts' );
function fudugo_gallery_addnew_item()
{
	wp_enqueue_media();
	//require_once FUDUGO_PLUGIN_DIR.'admin/addnew.php'; 
	require_once FUDUGO_PLUGIN_DIR.'admin/addnew-1.php'; 
}
 
 //Ajax Actions portfolio gallery page
add_action('wp_ajax_my_gallery_status','gallery_item_status');
add_action("wp_ajax_nopriv_my_gallery_status", "my_must_login");

function gallery_item_status() {
	$id = $_POST['id'];
	//echo $id;
	$gallery_helper = new GalleryHelper();
	if($gallery_helper->gallery_item_toggle_status($id)){
		//echo "Status Changed.";
	}else{
		echo "Error Ocurred.";
	}
}

add_action('wp_ajax_my_gallery_delete','gallery_item_delete');
add_action("wp_ajax_nopriv_my_gallery_delete", "my_must_login");

function gallery_item_delete() {
	$id = $_POST['id']; 
	$gallery_helper = new GalleryHelper();
	if($gallery_helper::deleteGalleryItem($id)){
		echo "Success";
	}else{
		echo "Error Ocurred.";
	}
}

// Ajax action to add new category or update
add_action( 'wp_ajax_add_category', 'add_new_category' );
function add_new_category() {
    if(isset($_POST['category']) && !empty($_POST['category'])){
    	$gallery_helper = new GalleryHelper();
    	if(!isset($_POST['editid'])){
	       
	        $res = $gallery_helper->addNewCategory($_POST);
	        if($res == 1){
	        	//$data = "Added Category :".$_POST['category'];

	        	$data = "Saved..";
	        	wp_send_json_success( $data );
	        }elseif($res == -1){
	        	$data = "Category already exists";
	        	wp_send_json_success($data); 
	        }else{
	        	//$data = "Error Occured";
	        	wp_send_json_error(); 
	        }
	    }else{
	    	if($gallery_helper->gallery_update_category($_POST)){
	    		$data = "Category Updated";
	        	wp_send_json_success($data);
	    	}else{ wp_send_json_error(); }
	    }
    } else {
        wp_send_json_error(); 
    }
}

// Ajax action to delete category
add_action('wp_ajax_my_gallery_category_delete','my_gallery_category_delete');
add_action("wp_ajax_nopriv_my_gallery_category_delete", "my_must_login");

function my_gallery_category_delete() {
	$id = $_POST['id']; 
	$gallery_helper = new GalleryHelper();
	if($gallery_helper::deleteCategory($id)){
		$data = "Category Deleted";
        	wp_send_json_success($data); 
	}else{
		wp_send_json_error();
	}
}

add_action('wp_ajax_my_gallery_category_status','togle_category_status');
add_action("wp_ajax_nopriv_my_gallery_category_status", "my_must_login");

function togle_category_status() {
	$id = $_POST['id'];
	$gallery_helper = new GalleryHelper();
	if($gallery_helper::gallery_category_toggle_status($id)){
		//wp_send_json_success(); 
	}else{wp_send_json_error();}
}

function media_selector_print_scripts() {

	$my_saved_attachment_post_id = get_option( 'media_selector_attachment_id', 0 );

	?><script type='text/javascript'>
		<?php include FUDUGO_PLUGIN_DIR.'js/admin-inc.js'; ?>
	</script><?php
}

function my_must_login() {
   echo "You must log in as a administrator to perform administrative actions";
   die();
}

 /**
  * actions for portfolio 
  **/

//adding action to add new portfolio form submit
add_action('admin_action_insert_portfolio', 'wpse10500_admin_action');
function wpse10500_admin_action()
{
	if(!empty($_POST) && check_admin_referer('fudugo_nonce_action','fudugo_nonce_field')) {
	    require_once(FUDUGO_PLUGIN_DIR.'includes/portfolio.class.php');
	    $portfolio = new PortfolioHelper();
	    if(!isset($_POST['editid']) || empty($_POST['editid'])){
		    if($portfolio->insert($_POST)){
		    	echo "Inserted Successfully";
		    }else{
		    	echo "Error Occured";
		    }
		}else{
			if($portfolio->update($_POST)){
		    	echo "Updated Successfully";
		    }else{
		    	echo "Error Occured";
		    }
		}
	}
    wp_redirect( $_SERVER['HTTP_REFERER'] );
    exit();
}

//Ajax actions for portfolio
add_action('wp_ajax_delete_portfolio','portfolio_delete');
add_action("wp_ajax_nopriv_delete_portfolio", "my_must_login");

function portfolio_delete() {
	$id = $_POST['id']; 
	$portfolio_helper = new PortfolioHelper();
	if($portfolio_helper::delete($id)){
		echo "deleted";
	}else{
		echo "Error Ocurred.";
	}
}

}