<?php defined( 'ABSPATH' ) or die( 'Direct Access is not allowed !' );
/**
*  Gallery Helper class.
*/
class GalleryHelper {
	  
	public function __construct() { 
		global $table_prefix;
		$GLOBALS[ 'content_table' ] = $table_prefix."fudugo_gallery_content";
		$GLOBALS['category_table'] = $table_prefix."fudugo_gallery_categories";
	}

	public function deleteGalleryItem($id) {
		global $table_prefix,$wpdb;
		if(empty($id) || $id==""){ 
			return false;
		}

		if ($wpdb->delete($GLOBALS['content_table'], array( 'ID' => $id ) )) {
			return true;
		}else{return false;}
	}

	public function gallery_item_toggle_status($id) {
		//define( 'WP_DEBUG', true );
		global $table_prefix,$wpdb;
		$content_table = $table_prefix."fudugo_gallery_content";
		
		$query = "SELECT status from ".$content_table." where id='".$id."'";
		
		$result = $wpdb->get_results($query);

		$stat = 0;
		if($result[0]->status==0){$stat = 1;}
		if($wpdb->update($content_table,array("status"=>$stat),array('id' => $id))){
			if ($stat==1) {
				echo "Active";
			}else{echo "Deactive";}
			return true;
		}else{
			return false;
		}
	}

	/* Categories */
	public function deleteCategory($id) {
		global $wpdb;
		$query = "delete from ".$GLOBALS['category_table']." where id='".$id."'";
		if ($wpdb->delete($GLOBALS['category_table'],array("id"=>$id))) {
				return 1; // successfull operation
			}else{return 0;/* unsuccess or error occured. */ }
	}

	public function addNewCategory($data){
		global $wpdb;
		$arr = array("title"=>"","status"=>"1","slug"=>"slug-1");
		$slug = sanitize_title($data['category']);
		$query = "SELECT id from ".$GLOBALS['category_table']." where slug like '".$slug."'";
		//echo $query;
		$dupentries = $wpdb->get_results($query);
		if($wpdb->num_rows<=0){
			$arr['title'] = $data['category'];
			$arr['status'] = $data['status'];
			$arr['slug'] = $slug;

			if($wpdb->insert($GLOBALS['category_table'],$arr)){
				return 1;
			}else{
				return 0;
			}
		}else{
			return -1;
		}
	}

	function gallery_update_category($data){
		//code $wpdb->update()
		global $wpdb;
		$array = array("title"=>"","status"=>"0");
		$slug = sanitize_title($data['category']);
		$array["title"] = $data["category"];
		$array["slug"] = $slug;
		$array["status"] = $data["status"];
		$array["modified_date"] = current_time("Y-m-d H:i:s");//date_format(new DateTime(),"Y-m-d H:m:s");

		if($wpdb->update($GLOBALS['category_table'], $array, array("id"=>$data["editid"]))) {
			return true;
		}else{
			return false;
		}
	}

	public function gallery_category_toggle_status($id) { 
		global $wpdb;
		$query = "SELECT status from ".$GLOBALS['category_table']." where id='".$id."'";
		
		$result = $wpdb->get_results($query);

		$stat = 0;
		if($result[0]->status==0){$stat = 1;}
		if($wpdb->update($GLOBALS['category_table'],array("status"=>$stat),array('id' => $id))){
			if ($stat==1) {
				echo "Active";
			}else{echo "Deactive";}
			return true;
		}else{
			return false;
		}
	}

}